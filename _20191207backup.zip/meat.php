<?php
$pageTitle = "Meat";
include('includes/header.php');
?>

<!-- start banner Area -->
<?php 
$Link_title = "King's Meat";
$Link_ref = "meat.php";
$Link_name = "Meat Department";
include('includes/nonindex-banner.php');
?>
<!-- End banner Area -->

<!-- Start menu-list Area -->
<?php include('includes/components/meat-items.php'); ?>
<!-- End menu-list Area -->


<?php include('includes/footer.php'); ?>