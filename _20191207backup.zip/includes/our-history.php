<section class="home-about-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-9">
							<h6 class="text-uppercase">10 Years of fast, fresh, and friendly service</h6>
							<h1>
								King's Bakery - Our History
							</h1>
							<p>
								<span>Below, we will put some text about King's History</span>
							</p>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore <br>
								t dolore magna aliqua. Ut enim ad minim. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do <br>
								eiusmod temp or incididunt ut labore et dolore magna aliqua. Ut enim ad minim. Lorem ipsum dolor sit amet, <br>
								consectetur adipisicing elit, sed do eiusmod temp or incididunt ut labore et dolore magna aliqua. 
							</p>
							<?php if ($keepButton) { ?>
								<a class="primary-btn squire mx-auto mt-20" href="about.php">Learn More About Us!</a>						
							<?php } ?>
						</div>
					</div>
				</div>	
				<img class="about-img" src="img/store-front.jpg" alt="" style="border-radius: 8px; margin-top: 5%;" height=400 width=500>
			</section>