<section class="home-about-area section-gap">
				<div class="container">
					<div class="row">
						<div class="col-lg-9">
							<h6 class="text-uppercase">At King's Bakery, you can taste the royalty</h6>
							<h1>
								Our Food is Made With YOU in Mind
							</h1>
							<p>
								<span>We are here to listen from you deliver exellence by any means</span>
							</p>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temp or incididunt ut labore et dolore magna aliqua. Ut enim ad minim. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod temp or incididunt ut labore et dolore magna aliqua. Ut enim ad minim.
							</p>
							<?php if ($keepButton != null) { ?>
								<a class="primary-btn squire mx-auto mt-20" href="about.php">Learn More About Us!</a>						
							<?php } ?>
						</div>
					</div>
				</div>	
				<img class="about-img" src="img/solo-sandwich.png" alt="" width="360" height="301">
			</section>