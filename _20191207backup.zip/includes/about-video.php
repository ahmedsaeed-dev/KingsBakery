<section class="about-video-area section-gap">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6 about-video-left">
				<h6 class="text-uppercase">Watch our featured video from Chow Down Detroit&trade;</h6>
				<h1>
					Chow Down Detroit&trade; <br>
					Loves Our New Pizza Fries
				</h1>
				<p>
					<span> </span>
				</p>
				<p>
					Check out our menu and experience the same great taste
				</p>
				<a class="primary-btn" href="menu.php">Check Our Menu</a>
			</div>
			<div class="col-lg-6 about-video-right justify-content-center align-items-center d-flex">
				<a class="play-btn" href="https://www.youtube.com/watch?v=x2Nh6yGvWLo"><img class="img-fluid mx-auto" src="img/play.png" alt=""></a>
			</div>
		</div>
	</div>
</section>