<?php
$pageTitle = "Menu";
include('includes/header.php');
?>

<!-- start banner Area -->
<?php 
$Link_title = "King's Menu";
$Link_ref = "menu.php";
$Link_name = "Menu";
include('includes/nonindex-banner.php');
?>
<!-- End banner Area -->

<!-- Start menu-list Area -->
<?php include('includes/components/menu-items.php'); ?>
<!-- End menu-list Area -->


<?php include('includes/footer.php'); ?>