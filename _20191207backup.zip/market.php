<?php
$pageTitle = "Market";
include('includes/header.php');
?>

<!-- start banner Area -->
<?php 
$Link_title = "King's Market";
$Link_ref = "market.php";
$Link_name = "Market";
include('includes/nonindex-banner.php');
?>
<!-- End banner Area -->

<!-- Start market-list Area -->
<?php include('includes/components/market-items.php'); ?>
<!-- End menu-list Area -->


<?php include('includes/footer.php'); ?>